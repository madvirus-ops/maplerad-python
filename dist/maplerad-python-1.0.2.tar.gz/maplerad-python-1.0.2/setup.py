# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['maplerad_python']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.31.0,<3.0.0']

setup_kwargs = {
    'name': 'maplerad-python',
    'version': '1.0.2',
    'description': 'API wrapper for Maplerad',
    'long_description': '# The Maplerad Python API Wrapper\n\nThe library follows an object-oriented approach\n\nThere are currently twelve (12) base categories namely:\n\n-   Customer\n-   Collections\n-   Transfer\n-   Bills\n-   Wallets\n-   Issuing\n-   Identity\n-   Transactions\n-   Counterparty\n-   Forex\n-   Institutions\n-   Misc\n\n#### Learn more from the [docs](https://maplerad.dev/reference)\n\n# Installation\n\n```shell\n $  pip install maplerad-python\n\n```\n\n# Authorization\n\nA secret key is needed for authorization. It can be gotten from the Maplerad dashboard\n\n# Environments\n\nMaplerad provides two environments to ensure a smooth and easy experience.\n\n-   sandbox: for development\n-   live: for production\n\n## Sandbox\n\nSandbox is your playground. You can credit your test wallets and use that to test your integrations, no real money will be debited or credited.\nEnsure to switch to Live when you are ready to launch.\n\n## Live\n\nAll method calls under Live will be charged and real money will be debited or credited.\nYou are advised to use this when you have fully tested your integrations and are ready to launch your product.\n\n# Usage\n\n```py\n# import the package\nfrom maplerad_python.auth import Authentication\n\n\nsecret_key = os.getenv("MAPLERAD_SECRET_KEY")\nenvironment = "DEVELOPMENT"\n\nauth = Authenticate(secret_key,environment)\n```\n\n## Get all Customers\n\n```py\ncustomer = auth.customers()\nresult = customer.get_all_customers()\n\n```\n\n## Create a Card\n\n```py\nissuing = auth.issuing()\npayload = {\n    "customer_id": "123456789",\n    "type": "VIRTUAL",\n    "currency": "USD",\n    "auto_approve": True,\n    "brand": "VISA",\n    "amount": 1000,\n    "card_pin": 1234\n    }\nresult = issuing.create_card(payload)\n\n\n\n```',
    'author': 'madvirus-ops',
    'author_email': 'edwinayabie1@gmail.com',
    'maintainer': 'madvirus-ops',
    'maintainer_email': 'edwinayabie1@gmail.com',
    'url': 'https://maplerad.com',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
